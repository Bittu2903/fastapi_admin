def get_example_message():
    return "Business logic here"